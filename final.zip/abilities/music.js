const { token, prefix, CHANNEL, SERVER, STATUS, LIVE } = require("./config.json");
const Discord = require('discord.js');
const client = new Discord.Client();
const config = require("./config.json");
const ytdl = require('ytdl-core');

module.exports = function (client) {
    const description = {
        name: "music",
        filename: "music.js",
        version: "final"
    }

client.on('ready', async () => {
    client.user.setActivity(STATUS + "Use !help")
    let channel = client.channels.cache.get(CHANNEL) || await client.channels.fetch(CHANNEL)
  
    if(!channel) return;
    const connection = await channel.join();
    connection.play(ytdl(LIVE))
  })
  
  setInterval(async function() {
    if(!client.voice.connections.get(SERVER)) {
      let channel = client.channels.cache.get(CHANNEL) || await client.channels.fetch(CHANNEL)
      if(!channel) return;
  
      const connection = await channel.join()
      connection.play(ytdl(LIVE))
    }
  }, 20000)
}