const { token, prefix, CHANNEL, SERVER, STATUS, LIVE } = require("./config.json");
const Discord = require('discord.js');
const client = new Discord.Client();
const config = require("./config.json");
const ytdl = require('ytdl-core');
const mongoose = require('mongoose');
const { ReactionRoleManager } = require('discord.js-collector')

mongoose.connect('mongodb+srv://Inavlid:1e2HFHYpKKsW03iu@cluster0.giq5x.mongodb.net/Data', { userNewUrlParser: true, useUnifiedTopology: true})

const music = require("./abilities/music.js");
const autorole = require("./abilities/autorole.js");
const commands = require("./abilities/commands.js"); 
const count = require("./abilities/count.js");
const chats = require("./abilities/chats.js");
const autoreact = require("./abilities/autoreact");
const jointocreate = require("./abilities/jointocreate");
jointocreate(client);
autoreact(client);
chats(client);
count(client);
commands(client);
autorole(client);
music(client);
client.login(token);