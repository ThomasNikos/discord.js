const Discord = require('discord.js');
const prefix = '!';
const client = new Discord.Client();

client.once('ready', () => {
    console.log('Invalid');
    client.user.setPresence({
        status: 'available',
        activity: {
            name: '!cmd | Luxurious',
            type: 'STREAMING',
            url: 'https://www.twitch.tv/invalid_input_'
        }
    });
});

const startTimestamps = new Map()

const pad2Digits = value => String(value).padStart(2, '0')

client.on('message', async message => {
  try {
    if (message.content === '!on') {
      // Sets the start time. This overrides any existing timers
      // Date.now() is equivalent to new Date().getTime()
      startTimestamps.set(message.author.id, Date.now())
      await message.reply('Βάρδια Ξεκίνησε.')
    } else if (message.content === '!off') {
      if (startTimestamps.has(message.author.id)) {
        // The user has an existing timer to stop
        // Calculate the timer result
        const ms = Date.now() - startTimestamps.get(message.author.id)
        const totalSecs = Math.floor(ms / 1000)
        const totalMins = Math.floor(totalSecs / 60)
        const hrs = Math.floor(totalMins / 60)
        const mins = totalMins % 60
        const secs = totalSecs % 60
        // Reply with result
        await message.reply(`Βάρδια Τελείωσε, Χρόνος: ${hrs}:${pad2Digits(mins)}:${pad2Digits(secs)}`)
        // Remove timestamp from map
        startTimestamps.delete(message.author.id)
      } else {
        // The user does not have an existing timer
        await message.reply('Πρώτα κάνε `!on` !')
      }
    }
  } catch (error) {
    console.error(error)
  }
})

client.on('message', message =>{

	let args = message.content.substring(prefix.length).split(" ");
	
	switch(args[0]){
		case 'app':
    			const embed = new Discord.MessageEmbed()
			.setTitle('** ``Applications`` **')
			.setColor('#d18013')
			.addField('** Staff 🔰 **', "> https://bit.ly/3chMO5A")	
			.addField('** ΕΛ.ΑΣ. 👮 **', "> https://bit.ly/3x05Ghh")	
			.addField('** Ε.Κ.Α.Β. 🥼 **', "> https://bit.ly/3ih9Ygf")		
			message.channel.send(embed);
			break;
	}	
});

client.on('message', message =>{

	let args = message.content.substring(prefix.length).split(" ");
	
	switch(args[0]){
		case 'cmd':
    			const embed = new Discord.MessageEmbed()
			.setTitle('** ``Commands`` **')
			.setColor('#d18013')
			.addField('** Server Status **', "> !status")	
			.addField('** Applications **', "> !app")	
			.addField('** Support **', "> !support")		
			message.channel.send(embed);
			break;
	}	
});

client.on('message', message =>{
	let args = message.content.substring(prefix.length).split(" ");
	switch(args[0]){
		case 'status':
	    const Gamedig = require('gamedig');
	    const image = 'https://media.discordapp.net/attachments/782254135965122581/850293021768548382/luxurioss.png'
	    Gamedig.query({
		type: 'fivem',
		host: 'play.diamondrp.live',
		port: '30120'
	    }).then((state) => {
		const status = new Discord.MessageEmbed()
		    .setColor('#00FF00')
		    .setTitle('𝕊𝔼ℝ𝕍𝔼ℝ 𝕀𝕊 𝕆ℕ𝕃𝕀ℕ𝔼')
		    .setThumbnail(image)
		    .setDescription('Ip')
		    .addField(`Players:`, `${state.raw.clients}/${state.maxplayers}`)
		message.channel.send(status)
	    }).catch((error) => {
		const status1 = new Discord.MessageEmbed()
		    .setColor('#ff0000')
		    .setTitle('𝕊𝔼ℝ𝕍𝔼ℝ 𝕀𝕊 𝕆𝔽𝔽𝕃𝕀ℕ𝔼')
		message.channel.send(status1)
	    });
	    }
	});

    client.on("message", message=>{
    if(message.channel.name === "🚙𝐕𝐞𝐡𝐢𝐜𝐥𝐞-𝐒𝐮𝐠𝐠𝐞𝐬𝐭𝐢𝐨𝐧𝐬"){
                   message.react("☑️")
	    	   message.react("❎")
    }
});

    client.on("message", message=>{
    if(message.channel.name === "👊𝐒𝐮𝐠𝐠𝐞𝐬𝐭𝐢𝐨𝐧𝐬"){
                   message.react("☑️")
	    	   message.react("❎")
    }
});

    client.on("message", message=>{
    if(message.channel.name === "🔍𝐏𝐨𝐥𝐥𝐬"){
                   message.react("☑️")
	    	   message.react("❎")
    }
});

    client.on("message", message=>{
    if(message.channel.name === "📷𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦"){
                   message.react("❤️")
    }
});

client.on('message', async message => {
    if(message.author.bot) return;

    if(message.channel.id === "829659942310510674"){
	const channel = client.channels.cache.get('829659942310510674');
	const webhooks = await channel.fetchWebhooks();
	const webhook = webhooks.first();
	const Attachment = message.attachments.first();	
	const dark = new Discord.MessageEmbed()
	.setDescription(message.content)
	.setColor('#00000')
	.setTimestamp()
	if (Attachment && Attachment.url) {dark.setImage(Attachment.url)}
	await webhook.send(dark)
	message.delete({ timeout: 0 })
    }
});


client.on('message', async message => {
    if(message.author.bot) return;
    if(message.channel.id === "829659743877857280"){
	const channel = client.channels.cache.get('829659743877857280');
	const webhooks = await channel.fetchWebhooks();
	const webhook = webhooks.first();
	const Attachment = message.attachments.first();	
	const insta = new Discord.MessageEmbed()
	.setAuthor(message.member.user.tag, message.author.avatarURL())
	.setTitle('📷 **Instagram**')
	.setDescription(message.content)
	.setColor('#ff9d00')
	.setTimestamp()
	.setFooter('Instagram', 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/600px-Instagram_icon.png')
	if (Attachment && Attachment.url) {insta.setImage(Attachment.url)}
	await webhook.send(insta)
	message.delete({ timeout: 1 })

    }
});

client.on('message', async message => {
    if(message.author.bot) return;
    if(message.channel.id === "829661772805177354"){
	const channel = client.channels.cache.get('829661772805177354');
	const webhooks = await channel.fetchWebhooks();
	const webhook = webhooks.first();
	const Attachment = message.attachments.first();	
	const insta = new Discord.MessageEmbed()
	.setAuthor(message.member.user.tag, message.author.avatarURL())
	.setTitle('📄 **χρυσός-οδηγός**')
	.setDescription(message.content)
	.setColor('#ff9d00')
	.setTimestamp()
	if (Attachment && Attachment.url) {insta.setImage(Attachment.url)}
	await webhook.send(insta)
	message.delete({ timeout: 1 })

    }
});

client.on('message', async message => {
    if(message.author.bot) return;
    if(message.channel.id === "829660333353992238"){
	const channel = client.channels.cache.get('829660333353992238');
	const webhooks = await channel.fetchWebhooks();
	const webhook = webhooks.first();
	const Attachment = message.attachments.first();	
	const insta = new Discord.MessageEmbed()
	.setAuthor(message.member.user.tag, message.author.avatarURL())
	.setTitle('**ΕΡΤ**')
	.setDescription(message.content)
	.setColor('#FFFFFF')
	.setTimestamp()
	if (Attachment && Attachment.url) {insta.setImage(Attachment.url)}
	await webhook.send(insta)
	message.delete({ timeout: 1 })

    }
});

client.on('message', message =>{

	let args = message.content.substring(prefix.length).split(" ");
	
	switch(args[0]){
		case 'support':
    			const embed = new Discord.MessageEmbed()
			.setDescription("Ένας <@&829648280551686164> θα σας εξυπηρετήσει άμεσα")
			message.channel.send(embed);
			break;
	}	
});

const jointocreate = require("./jointocreate");
jointocreate(client);
client.login(process.env.token);
