const Discord = require('discord.js');
const client = new Discord.Client();
const prefix = '!';
const config = require("./config.json");

let stats = {
	serverID: '773952797556080670',
	total: "776762805280964648"
};

client.once('ready', () => { 
    console.log('Έλα μαλάκα αναστήθηκα');
    client.user.setPresence({
    status: 'online',
    activity: {
    type: 'STREAMING',
     name: 'Use !ip',
},
});
});

client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'help'){
        message.channel.send('Use ?ip');
    }
});

client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'ip'){
        message.channel.send('connect prodigyrp.ddns.net');
    }
});

client.on('message', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();

    if(command === 'support'){
        message.channel.send(`Ένα <@&792511390023811083> να εξυπηρετήσει τον/την ${message.author.toString()} στο 📞𝐖𝐚𝐢𝐭𝐢𝐧𝐠 𝐟𝐨𝐫 𝐒𝐮𝐩𝐩𝐨𝐫𝐭`);
    }
});

    client.on("message", message=>{
    if(message.channel.name === "🚙𝐕𝐞𝐡𝐢𝐜𝐥𝐞-𝐒𝐮𝐠𝐠𝐞𝐬𝐭𝐢𝐨𝐧𝐬"){
                   message.react("☑️")
	    	   message.react("❎")
    }
});

    client.on("message", message=>{
    if(message.channel.name === "👊𝐒𝐮𝐠𝐠𝐞𝐬𝐭𝐢𝐨𝐧𝐬"){
                   message.react("☑️")
	    	   message.react("❎")
    }
});

    client.on("message", message=>{
    if(message.channel.name === "🔍𝐏𝐨𝐥𝐥𝐬"){
                   message.react("☑️")
	    	   message.react("❎")
    }
});

    client.on("message", message=>{
    if(message.channel.name === "📷𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦"){
                   message.react("❤️")
    }
});

client.on('message', async message => {
    if(message.author.bot) return;

    if(message.channel.id === "775756302227865630"){
	const channel = client.channels.cache.get('775756302227865630');
	const webhooks = await channel.fetchWebhooks();
	const webhook = webhooks.first();
	const Attachment = message.attachments.first();	
	const dark = new Discord.MessageEmbed()
	.setDescription(message.content)
	.setColor('#00000')
	.setTimestamp()
	if (Attachment && Attachment.url) {dark.setImage(Attachment.url)}
	await webhook.send(dark)
	message.delete({ timeout: 0 })
    }
});


client.on('message', async message => {
    if(message.author.bot) return;
    if(message.channel.id === "775756686437908520"){
	const channel = client.channels.cache.get('775756686437908520');
	const webhooks = await channel.fetchWebhooks();
	const webhook = webhooks.first();
	const Attachment = message.attachments.first();	
	const insta = new Discord.MessageEmbed()
	.setAuthor(message.member.user.tag, message.author.avatarURL())
	.setTitle('📷 **Instagram**')
	.setDescription(message.content)
	.setColor('#ff9d00')
	.setTimestamp()
	.setFooter('Instagram', 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/600px-Instagram_icon.png')
	if (Attachment && Attachment.url) {insta.setImage(Attachment.url)}
	await webhook.send(insta)
	message.delete({ timeout: 1 })

    }
});

const jointocreate = require("./jointocreate");
jointocreate(client);
client.login(process.env.token);
