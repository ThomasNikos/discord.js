module.exports = {
    green: "#2BFF59",
    orange: "#FFD132",
    blue: "#a7d6fd",
    red: "#FF360B",
    pink:"#C597B8",
    yellow:"#FFFF00"
  }